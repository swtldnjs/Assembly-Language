#include <stdint.h>
void Terminal_setup(void);
void WriteChar(char);
void NewLine(void);
void WriteString(char*);
void WriteDec(uint32_t);
void WriteInt(int32_t);
void WriteFloat(float);
char ReadChar(void);
uint8_t ReadString(char*, uint8_t);
int32_t ReadInt(void);
float ReadFloat(void);
void WriteBin(uint32_t d);
