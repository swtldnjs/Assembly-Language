#include <em_device.h>						// header for all micro registers
#include "hardware.h"						// custom headers
#include "terminal.h"

int main()
{
	Terminal_setup()						// configure terminal I/O
	GPIO_setup();							// configure GPIO ports									
	
	while(1)								// main application loop
	{	

	}	
}

