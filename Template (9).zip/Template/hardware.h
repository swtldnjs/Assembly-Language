#include <stdint.h>
void GPIO_setup(void);							// configure GPIO ports	
void LETIMER_setup(void);						// configure low-power timer
