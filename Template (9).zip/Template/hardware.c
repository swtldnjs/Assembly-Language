#include <em_device.h>
#include "hardware.h"

void GPIO_setup(void)
{
	CMU->CLKEN0_SET = CMU_CLKEN0_GPIO;
	(GPIO->P[0]).MODEL |= GPIO_P_MODEL_MODE4_PUSHPULL;
}

void LETIMER_setup(void)
{
	CMU->CLKEN0_SET = CMU_CLKEN0_LETIMER0; 				// enable LFA clock for LETIMER
	LETIMER0->CTRL = LETIMER_CTRL_CNTTOPEN; 
	LETIMER0->TOP = 32767;										// 1 second setup
	LETIMER0->EN = LETIMER_EN_EN;
	LETIMER0->IEN_SET = LETIMER_IEN_UF;		
	LETIMER0->CMD = LETIMER_CMD_START + LETIMER_CMD_CLEAR;
	NVIC_EnableIRQ(LETIMER0_IRQn);
}
