#include "io.h"
extern void Terminal_setup(void);
extern int WriteChar(int ch);
extern int ReadChar(void);
extern int ReadString(char *, int);
float ReadFloat(void);
int stdout_putchar (int ch);
int stderr_putchar (int ch);
int stdin_getchar(void);

int stdout_putchar (int ch) 
{
	WriteChar(ch);
	return(0);
}

int stderr_putchar (int ch) 
{
	WriteChar(ch);
	return(0);
}

int stdin_getchar(void)
{
	return ReadChar();
}

float ReadFloat(void)
{
	char str[10];
	ReadString(str, 9);
	return (float)atof(str);
}

void WriteFloat(float f)
{
	printf("%f", (double)f);	
}

