#include <stdio.h>
#include <stdlib.h>

extern void Terminal_setup(void);
float ReadFloat(void);
void WriteFloat(float);
